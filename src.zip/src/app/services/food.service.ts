import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class FoodService {
  
  constructor(private http:HttpClient) { }
    
   /*--------------------All Food Related API Method-----------------  */
   private URL:string='';
   /*Get All Foods  */
   getAllFoods(){
      return this.http.get('https://foodordersystem.glitch.me/api/foods');
   }

   
}
