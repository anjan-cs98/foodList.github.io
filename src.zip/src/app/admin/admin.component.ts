import { Component } from '@angular/core';
import { FoodService } from '../services/food.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent {
  public foodList:any=[];
  public page:number=1;
  constructor(private fService:FoodService){}


ngOnInit(): void {
   /* Now call the populatefooods*/
   this.populateFoods();    
}


/* Populate all foodList */
populateFoods(){
    this.fService.getAllFoods().subscribe({
      next:((res:any)=>{
        console.log(res);
        this.foodList=res;
      }),
      error:((error:any)=>{
         console.log(error);
      }),
      complete:(()=>{
        console.log('API call Successfully.....');
      })
    });
}

}
